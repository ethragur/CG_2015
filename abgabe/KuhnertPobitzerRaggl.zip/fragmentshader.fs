#version 330

in vec4 vColor;

out vec4 FragColor;

void main()
{
    FragColor = vColor;
}